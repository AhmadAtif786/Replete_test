import { getEnsDomain } from './ens';

export const domainFetchers = [getEnsDomain];
