import { t } from '@lingui/macro';

export const eModeInfo: { [key: number]: { label: string } } = {
  1: {
    label: t`Stablecoin`,
  },
};
