export enum CapType {
  'supplyCap' = 'supplyCap',
  'borrowCap' = 'borrowCap',
}
