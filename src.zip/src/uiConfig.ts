export const uiConfig = {
  appLogo: '/Replete_logo.png',
};
